(function () {
  const dropdownBtn = document.querySelector('[data-dropdown-btn]');
  const dropdown = document.querySelector('[data-dropdown]');
  if (dropdownBtn && dropdown) {
    dropdownBtn.addEventListener('click', (e) => {
      e.preventDefault();
      dropdown.classList.toggle('open');
      dropdownBtn.setAttribute('aria-expanded', dropdown.classList.contains('open') ? 'true' : 'false');
    });
    document.addEventListener('click', (e) => {
      if (!dropdown.contains(e.target)) {
        dropdown.classList.remove('open');
        dropdownBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  const mobileToggle = document.querySelector('[data-mobile-toggle]');
  const nav = document.querySelector('[data-nav]');
  if (mobileToggle && nav) {
    mobileToggle.addEventListener('click', () => {
      nav.classList.toggle('mobile-open');
      mobileToggle.setAttribute('aria-expanded', nav.classList.contains('mobile-open') ? 'true' : 'false');
    });
  }

  // Hero skyline rotator (3 images, ~3s each)
  const slides = document.querySelectorAll('[data-hero-slide]');
  let idx = 0;
  if (slides.length) {
    slides.forEach((s, i) => s.classList.toggle('active', i === 0));
    setInterval(() => {
      slides[idx].classList.remove('active');
      idx = (idx + 1) % slides.length;
      slides[idx].classList.add('active');
    }, 3000);
  }
})();
