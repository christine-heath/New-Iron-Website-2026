NEW IRON WEBSITE BUILD KIT (Netlify-ready HTML)

Files included
- index.html (Home)
- employers-semi.html (For Employers - Semiconductor / Industrial)
- employers-saas.html (For Employers - SaaS / Product / Cloud / IT)
- engagement-models.html (Engagement Models)
- expertise.html (Expertise & Success)
- how-we-work.html (How We Work)
- team.html (Our Team)
- candidates.html (For Candidates)
- jobs.html (Jobs page placeholder for Vincere embed)
- contact.html (Contact page with Netlify forms)
- thanks.html (Form submission confirmation page)
- assets/styles.css
- assets/site.js
- assets/img/* (logos + page images)

NETLIFY DEPLOY (fastest path)
1) In Netlify, click Add new site -> Deploy manually.
2) Drag and drop the unzipped site folder (the folder that contains index.html).
3) After the first deploy, set your custom domain in Netlify:
   - Site configuration -> Domain management -> Add domain
   - Follow Netlify DNS steps, or keep DNS at Wix and point the domain records to Netlify.

FORMS (contact page)
- The contact forms are already wired for Netlify Forms.
- Netlify will detect them on deploy and collect submissions.
- To send submissions to newiron@newiron.com:
  1) Open your Netlify site dashboard
  2) Forms -> choose a form (employer-intake or candidate-inquiry)
  3) Notifications -> Add notification -> Email
  4) Enter: newiron@newiron.com
  5) Repeat for the second form (or add notifications for both)

JOBS PAGE (Vincere)
- Open jobs.html
- Replace the placeholder block with the Vincere embed code (iframe/script) from Vincere
- Publish a new Netlify deploy

NOTES
- This is a static HTML/CSS/JS site (no Wix dependencies).
- All Wix-related placeholder copy has been removed from page content.
